#!/bin/bash

# Check if an argument is provided
if [ "$#" -ne 1 ]; then
    echo "Usage: $0 <debug|release>"
    exit 1
fi

MODE=$1
EXECUTABLE_NAME="Control.jtt"

if ! echo '#include <curl/curl.h>' | g++ -x c++ -fsyntax-only - 2>/dev/null; then
    echo "Missing libcurl headers. On this machine run:"
    echo "  apt update && apt install -y libcurl4-openssl-dev"
    exit 1
fi
INCLUDE_PATH="./include" # Path to the directory containing header files
LOG_FILE="compile_log.txt"
RUN_DURATION=10 # Duration in seconds for the test run

# Compile the code based on the mode
if [ "$MODE" = "debug" ]; then
    echo "Compiling in debug mode..." | tee $LOG_FILE
    g++ -g -I$INCLUDE_PATH -o $EXECUTABLE_NAME ./src/*.cpp ./main.cpp -lcurl -lpthread -lcryptopp 2>&1 | tee -a $LOG_FILE
elif [ "$MODE" = "release" ]; then
    echo "Compiling in release mode..." | tee $LOG_FILE
    g++ -O2 -I$INCLUDE_PATH -o $EXECUTABLE_NAME ./src/*.cpp ./main.cpp -lcurl -lpthread -lcryptopp 2>&1 | tee -a $LOG_FILE
else
    echo "Invalid mode: $MODE" | tee $LOG_FILE
    exit 1
fi

# Check if the compilation was successful
if [ -f "$EXECUTABLE_NAME" ]; then
    # Run the compiled program for a limited time
    echo "Running the program for $RUN_DURATION seconds..." | tee -a $LOG_FILE
    timeout $RUN_DURATION ./$EXECUTABLE_NAME
    if [ $? -eq 124 ]; then
        echo "Program terminated after $RUN_DURATION seconds." | tee -a $LOG_FILE
    else
        echo "Program completed or terminated before timeout." | tee -a $LOG_FILE
    fi
else
    echo "Compilation failed, see $LOG_FILE for details."
fi
