#ifndef UTILITIES_H
#define UTILITIES_H

#include <iostream>
#include <vector>
#include <string>

// Encriptação
#include <crypto++/rsa.h>
#include <crypto++/osrng.h>
#include <crypto++/base64.h>
#include <crypto++/files.h>
#include <crypto++/md5.h>
#include <crypto++/hex.h>

//#define byte unsigned char


class Utilities
{
	public:
	    //static int m[256];
		static float byte_to_float(const unsigned char b[4]);
		static std::vector<unsigned char> str_to_char_V(std::string source);
		static std::string char_V_to_str(std::vector<unsigned char> source);
		static std::string base64_decode(const std::string &in);
		static std::string base64_encode(const std::string &in);
		static std::vector<std::string> splitString(const std::string& input, int chunkSize);
		static std::string base32_encode(const std::string& input);
		static std::string EncryptData(const std::string &plainText, const std::string &publicKeyStr);
		static std::string decryptRSA(const std::string& encryptedMessage,std::string privateKeyString);
		static void testKeyGeneration();
		static std::string CalculateMD5(const std::string& input);
};

#endif // UTILITIES_H
