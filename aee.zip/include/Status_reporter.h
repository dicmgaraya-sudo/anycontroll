#ifndef STATUS_REPORTER_H
#define STATUS_REPORTER_H

#include <string>

struct HttpResult {
	bool ok;
	long http_code;
	long latency_ms;
	std::string body;
};

class Status_reporter {
public:
	static HttpResult http_post(const std::string& data, const std::string& destination);
	static std::string endpoint_url(const std::string& filename);
	static std::string host_name();
	static void send_status(bool modbus_ok,
		bool serial_present,
		int device_count,
		bool mea_ok,
		const std::string& mea_detail,
		long mea_latency_ms);
	static void send_event(const std::string& component,
		const std::string& status,
		const std::string& event_code,
		const std::string& message);
};

#endif
