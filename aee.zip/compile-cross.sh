#!/bin/bash

set -o pipefail

if [ "$#" -ne 1 ]; then
    echo "Usage: $0 <debug|release>"
    echo "Cross-compiles Control.jtt for Raspberry Pi 3 (arm64 / 64-bit)."
    echo ""
    echo "1) Cross-compiler:"
    echo "   sudo apt install g++-aarch64-linux-gnu"
    echo ""
    echo "2) ARM64 libraries:"
    echo "   Prefer a Pi sysroot (most reliable):"
    echo "   mkdir -p ~/rpi-sysroot/lib ~/rpi-sysroot/usr/lib ~/rpi-sysroot/usr/include"
    echo "   rsync -aL --delete-after USER@PI:/lib/ ~/rpi-sysroot/lib/"
    echo "   rsync -aL --delete-after USER@PI:/usr/lib/ ~/rpi-sysroot/usr/lib/"
    echo "   rsync -aL --delete-after USER@PI:/usr/include/ ~/rpi-sysroot/usr/include/"
    echo "   SYSROOT=\$HOME/rpi-sysroot $0 release"
    echo ""
    echo "Optional: SYSROOT=/path/to/pi/rootfs $0 release"
    exit 1
fi

MODE=$1
EXECUTABLE_NAME="Control.jtt"
INCLUDE_PATH="./include"
LOG_FILE="compile_log_cross.txt"
CXX="${CXX:-aarch64-linux-gnu-g++}"
TARGET_FLAGS="-march=armv8-a -mtune=cortex-a53"

if ! command -v "$CXX" >/dev/null 2>&1; then
    echo "Cross-compiler not found: $CXX"
    echo "Install with: sudo apt install g++-aarch64-linux-gnu"
    exit 1
fi

SYSROOT_FLAGS=()
if [ -n "$SYSROOT" ]; then
    if [ ! -d "$SYSROOT" ]; then
        echo "SYSROOT does not exist: $SYSROOT"
        exit 1
    fi
    SYSROOT_FLAGS=(--sysroot="$SYSROOT" -I"$SYSROOT/usr/include" -I"$SYSROOT/usr/include/aarch64-linux-gnu" -L"$SYSROOT/usr/lib/aarch64-linux-gnu" -L"$SYSROOT/lib/aarch64-linux-gnu")
    echo "Using SYSROOT=$SYSROOT" | tee "$LOG_FILE"
else
    echo "No SYSROOT set; using host arm64 cross-libraries if available." | tee "$LOG_FILE"
fi

COMMON_FLAGS=(-I"$INCLUDE_PATH" "${SYSROOT_FLAGS[@]}" $TARGET_FLAGS -o "$EXECUTABLE_NAME" ./src/*.cpp ./main.cpp -lcurl -lpthread -lcryptopp)

if [ "$MODE" = "debug" ]; then
    echo "Cross-compiling (Pi 3 / arm64) in debug mode with $CXX..." | tee -a "$LOG_FILE"
    $CXX -g "${COMMON_FLAGS[@]}" 2>&1 | tee -a "$LOG_FILE"
elif [ "$MODE" = "release" ]; then
    echo "Cross-compiling (Pi 3 / arm64) in release mode with $CXX..." | tee -a "$LOG_FILE"
    $CXX -O2 "${COMMON_FLAGS[@]}" 2>&1 | tee -a "$LOG_FILE"
else
    echo "Invalid mode: $MODE" | tee -a "$LOG_FILE"
    exit 1
fi

if [ $? -eq 0 ] && [ -f "$EXECUTABLE_NAME" ]; then
    echo "OK: $EXECUTABLE_NAME ready for Raspberry Pi 3 arm64." | tee -a "$LOG_FILE"
    file "$EXECUTABLE_NAME" 2>/dev/null | tee -a "$LOG_FILE" || true
    echo "Copy to Pi, e.g.: scp $EXECUTABLE_NAME pi@raspberrypi:~/" | tee -a "$LOG_FILE"
else
    echo "Compilation failed, see $LOG_FILE for details."
    exit 1
fi
