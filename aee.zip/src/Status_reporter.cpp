#include "Status_reporter.h"

#include "Config_maneger.h"
#include "Utilities.h"

#include <chrono>
#include <curl/curl.h>
#include <unistd.h>

#include "nlohmann/json.hpp"

namespace {
	size_t write_callback(char* contents, size_t size, size_t nmemb, char* buffer_in) {
		((std::string*)buffer_in)->append((char*)contents, size * nmemb);
		return size * nmemb;
	}
}

HttpResult Status_reporter::http_post(const std::string& data, const std::string& destination) {
	HttpResult result;
	result.ok = false;
	result.http_code = 0;
	result.latency_ms = 0;

	CURL* curl = curl_easy_init();
	if (!curl) {
		return result;
	}

	const auto started = std::chrono::steady_clock::now();
	struct curl_slist* hs = NULL;
	curl_easy_setopt(curl, CURLOPT_URL, destination.c_str());
	curl_easy_setopt(curl, CURLOPT_HTTPHEADER, hs);
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data.c_str());
	curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, data.length());
	curl_easy_setopt(curl, CURLOPT_POST, 1L);
	curl_easy_setopt(curl, CURLOPT_TIMEOUT, 30L);
	curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 10L);
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, &result.body);

	const CURLcode res = curl_easy_perform(curl);
	const auto ended = std::chrono::steady_clock::now();
	result.latency_ms = std::chrono::duration_cast<std::chrono::milliseconds>(ended - started).count();

	if (res == CURLE_OK) {
		curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &result.http_code);
		result.ok = result.http_code >= 200 && result.http_code < 300;
	}

	curl_slist_free_all(hs);
	curl_easy_cleanup(curl);
	return result;
}

std::string Status_reporter::endpoint_url(const std::string& filename) {
	const std::string& base = Config_maneger::PHP_Server_Addr;
	const size_t pos = base.find_last_of('/');
	if (pos == std::string::npos) {
		return filename;
	}
	return base.substr(0, pos + 1) + filename;
}

std::string Status_reporter::host_name() {
	char buf[256];
	if (gethostname(buf, sizeof(buf)) == 0) {
		buf[sizeof(buf) - 1] = '\0';
		return std::string(buf);
	}
	return "unknown";
}

void Status_reporter::send_status(bool modbus_ok,
	bool serial_present,
	int device_count,
	bool mea_ok,
	const std::string& mea_detail,
	long mea_latency_ms) {
	nlohmann::json payload;
	payload["unique_ID"] = Config_maneger::Setup_ID;
	payload["host"] = host_name();
	payload["app_version"] = "anycontroller";

	nlohmann::json components = nlohmann::json::array();

	components.push_back({
		{"name", "host"},
		{"status", "ok"},
		{"detail", host_name()}
	});

	components.push_back({
		{"name", "network"},
		{"status", mea_ok ? "ok" : "warn"},
		{"detail", mea_ok ? "rota ate MEA responsiva" : "falha de rede ou MEA"}
	});

	components.push_back({
		{"name", "modbus_tcp"},
		{"status", modbus_ok ? "ok" : "fail"},
		{"detail", modbus_ok
			? ("adaptor " + Config_maneger::adaptor_Addr + ":502")
			: ("sem resposta em " + Config_maneger::adaptor_Addr + ":502")}
	});

	components.push_back({
		{"name", "modbus_serial"},
		{"status", serial_present ? "ok" : "offline"},
		{"detail", serial_present ? "porta serial detectada" : "sem /dev/ttyUSB* ou ttyS*"}
	});

	std::string meter_status = "ok";
	std::string meter_detail = std::to_string(device_count) + " medidor(es)";
	if (device_count <= 0) {
		meter_status = modbus_ok ? "warn" : "fail";
		meter_detail = "nenhum medidor encontrado";
	}
	components.push_back({
		{"name", "meter"},
		{"status", meter_status},
		{"detail", meter_detail},
		{"meta", {{"count", device_count}}}
	});

	components.push_back({
		{"name", "mea"},
		{"status", mea_ok ? "ok" : "fail"},
		{"detail", mea_detail},
		{"latency_ms", mea_latency_ms}
	});

	payload["components"] = components;

	const std::string body = "crypt=" + Utilities::base32_encode(payload.dump());
	const HttpResult result = http_post(body, endpoint_url("save_device_status.php"));
	std::cout << "status post: " << (result.ok ? "OK" : "FAIL")
		<< " http=" << result.http_code
		<< " " << result.body << "\n";
}

void Status_reporter::send_event(const std::string& component,
	const std::string& status,
	const std::string& event_code,
	const std::string& message) {
	nlohmann::json payload;
	payload["unique_ID"] = Config_maneger::Setup_ID;
	payload["component"] = component;
	payload["status"] = status;
	payload["event_code"] = event_code;
	payload["message"] = message;

	const std::string body = "crypt=" + Utilities::base32_encode(payload.dump());
	const HttpResult result = http_post(body, endpoint_url("save_device_event.php"));
	std::cout << "event post: " << event_code << " "
		<< (result.ok ? "OK" : "FAIL")
		<< " " << result.body << "\n";
}
