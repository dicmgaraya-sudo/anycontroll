#include "MODBUS.h"

#include <string>
#include <vector>

#include <iostream>
#include <cstdint>
#include <cstring>

#define byte unsigned char

std::vector<float> Modbus::process_response(std::vector<char> response)
{
	std::vector<float> processed;

	for (int i = 0; i < response.size(); i += 4) {

		byte bt[4] = {
			response[response.size() - i - 1],
			response[response.size() - i - 2],
			response[response.size() - i - 3],
			response[response.size() - i - 4]
		};

		processed.push_back(Utilities::byte_to_float(bt));
	}
	return processed;
}


std::vector<byte> Modbus::CRC_16(unsigned char* buf, int len)
{
	unsigned int crc = 0xFFFF;
	for (int pos = 0; pos < len; pos++)
	{
		crc ^= (unsigned int)buf[pos];    // XOR byte into least sig. byte of crc

		for (int i = 8; i != 0; i--) {    // Loop over each bit
			if ((crc & 0x0001) != 0) {      // If the LSB is set
				crc >>= 1;                    // Shift right and XOR 0xA001
				crc ^= 0xA001;
			}
			else                            // Else LSB is not set
				crc >>= 1;                    // Just shift right
		}
	}

	char byteArray[sizeof(crc)];
	std::vector<byte> res;

	std::memcpy(byteArray, (const char*)&crc, sizeof(crc));

	res.push_back(byteArray[0]);
	res.push_back(byteArray[1]);

	return res;
}

std::vector<char> Modbus::separete_data(std::vector<char> vec, short data_len, short cut) {
	for (int i = 0; i < cut; i++)
		vec.erase(vec.begin());

	cut = vec.size() - data_len;
	for (int i = 0; i < cut; i++)vec.pop_back();

	return vec;
}
