#include "serial_conn.h"
#include "Modbus_Serial.h"

#define byte unsigned char

std::string serial_conn::serial_devices;

serial_conn::serial_conn()
{
    //ctor
}

serial_conn::~serial_conn()
{
    //dtor
}

std::vector<std::string> serial_conn::getSerialPortList() {
    glob_t glob_result;
    std::vector<std::string> serialPorts;

    // Get the list of files matching the pattern /dev/ttyS*
    glob("/dev/ttyS*", GLOB_TILDE, NULL, &glob_result);
    std::cout << "The length of the vector /dev/ttyS* is: " << glob_result.gl_pathc << std::endl;

    for (unsigned int i = 0; i < glob_result.gl_pathc; ++i) {
        serialPorts.push_back(std::string(glob_result.gl_pathv[i]));
    }

    // Get the list of files matching the pattern /dev/ttyUSB*
    glob("/dev/ttyUSB*", GLOB_TILDE | GLOB_APPEND, NULL, &glob_result);
    std::cout << "The length of the vector /dev/ttyUSB* is: " << glob_result.gl_pathc << std::endl;

    for (unsigned int i = 0; i < glob_result.gl_pathc; ++i) {
        serialPorts.push_back(std::string(glob_result.gl_pathv[i]));
    }
    std::cout<<  "1."<< std::endl;
    globfree(&glob_result);
    return serialPorts;
}

bool serial_conn::checkSerialPortConnection(const std::string &port ) {

    int fileDescriptor = open(port.c_str(), O_RDWR | O_NOCTTY | O_NDELAY);

    if (fileDescriptor < 0) {
        int err = errno;
        std::cout << "Comunication not possible on port: " << port << std::endl;
        switch (err) {
            case EACCES:
                std::cout<<  "Permission denied to access the serial port."<< std::endl;
                break;
            case ENOENT:
                std::cout<<  "Serial port does not exist."<< std::endl;
                break;
            case EBUSY:
                std::cout<<  "Serial port is in use by another process."<< std::endl;
                break;
            case EINVAL:
                std::cout<<  "Invalid port path."<< std::endl;
            default:
                std::cout<<  "Unknown error (" + std::to_string(err) + "): " << std::endl;
                break;
        }
        return false;
    } else {
        std::cout<<  "2."<< std::endl;
        serial_devices = port;
        return hand_shake();
    }
}

bool serial_conn::hand_shake(){
    Modbus_Serial MS = Modbus_Serial();
    const short addr = 0x2000;
    const short length = 2;

    for(short i = 1; i<240; i++){
        const std::vector<char> hold_data =  MS.Read_from_Device(i, (byte*)&addr, (byte*)&length);
        for(int j = 0; j < 4;j++){
            if(hold_data[j] != 0){
                std::cout<<"Encontrado em: "<< serial_devices<<std::endl;
                //std::cin.ignore();
                return true;
            }
        }
    }
    return false;
}

std::vector<char> serial_conn::SendBytes(const std::string &port, unsigned char* msg, short length){

    std::cout << "Enviado "<<port.c_str()<<":";
    for(int i = 0; i < length;++i){
        std::cout << std::hex << static_cast<int>(msg[i])<< " ";
    }
    std::cout<<std::endl;

    int fileDescriptor = open(port.c_str(), O_RDWR | O_NOCTTY | O_NDELAY);
    fcntl(fileDescriptor, F_SETFL, 0); // Reset file descriptor flags to blocking mode

    struct termios options;
    tcgetattr(fileDescriptor, &options);
    cfsetispeed(&options, B9600);
    cfsetospeed(&options, B9600);
    options.c_cflag |= (CLOCAL | CREAD); // Enable the receiver and set local mode
    options.c_cflag &= ~PARENB; // No parity
    options.c_cflag &= ~CSTOPB; // One stop bit
    options.c_cflag &= ~CSIZE; // Mask data size
    options.c_cflag |= CS8; // 8 bits
    options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG); // Raw input mode
    options.c_iflag &= ~(IXON | IXOFF | IXANY); // No software flow control
    options.c_oflag &= ~OPOST; // Raw output mode
    tcsetattr(fileDescriptor, TCSANOW, &options); // Apply the new terminal options

    write(fileDescriptor, msg, length);
    usleep(100000);

    // Read the response from the device (assuming it echoes the message back)
    std::vector<char> buffer(256);

    //Set up timeout
    struct timeval timeout;
    timeout.tv_sec = 0.3;
    timeout.tv_usec = 0;

    //Prepare the file descriptor
    fd_set read_fds;
    FD_ZERO(&read_fds);
    FD_SET(fileDescriptor, &read_fds);

    //Wait for data to be avaliable or timeout to occur
    int select_result = select(fileDescriptor +1, &read_fds, NULL, NULL, &timeout);
    int bytesRead = 0;

    if(select_result > 0 && FD_ISSET(fileDescriptor, &read_fds)){
        bytesRead = read(fileDescriptor, buffer.data(), buffer.size());
    }else if(select_result == 0){
        std::cout << "Timeout: Sem dispositivo no endereço" << std::endl;
        return buffer;
    }else {
        std::cout << "Error occurred during select: "<< strerror(errno)<< std::endl;
        return buffer;
    }

    if(bytesRead<buffer.size()){
        buffer[bytesRead] = '\0';
    }else{
        buffer.back() = '\0';
    }

    if(bytesRead == 0){
        std::cout<<std::endl;
        return buffer;
    }
    std::cout << "Resposta:";
    for(int i = 0; i < sizeof(buffer);++i){
        std::cout << std::hex << static_cast<int>(buffer[i])<< " ";
    }
    std::cout<<std::endl;
    // Close the file descriptor
    close(fileDescriptor);

    return buffer;

}

bool serial_conn::check_all_Ports() {
    std::vector<std::string> serialPorts = getSerialPortList();

    for (const std::string &port : serialPorts) {
        std::cout<<  "3."<< std::endl;
        if (checkSerialPortConnection(port)){
            std::cout << port << std::endl;
            serial_devices = port;
            return true;
        }
    }
    return false;
}
