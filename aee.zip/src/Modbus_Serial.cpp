#include "Modbus_Serial.h"



std::vector<char> Modbus_Serial::Read_from_Device(const unsigned char device_ID, const  unsigned char* reg_addr, const unsigned char* length)
{
	std::vector<char>  res;

		unsigned char Code_RTU[6] = {
				device_ID,					//device
				0x03,						//read command
				reg_addr[1],reg_addr[0],	//registor
				length[1],length[0]
		};
		std::vector<unsigned char> crc = Modbus::CRC_16(Code_RTU, sizeof(Code_RTU));

		unsigned char msg[8] = {
						Code_RTU[0],Code_RTU[1],	//read command
						Code_RTU[2],Code_RTU[3],	//registor
						Code_RTU[4],Code_RTU[5],	//length
						crc[0],crc[1]				//CRC
						};

		if (res.size() > 1)
		{
			return separete_data(res, 2 * length[0], 3);;
		}


	return res;
}


std::vector<char> Modbus_Serial::Write_to_Device(unsigned char device_ID, unsigned char* reg_addr, unsigned char* length, const unsigned char* data)
{
	std::vector<char>  res;


		unsigned char Code_RTU[9] = {
				device_ID,
				0x10,//write command
				reg_addr[1],reg_addr[0], //registor
				length[1],length[0],
				2 * length[0],
				data[0],data[1]
		};

		std::vector<unsigned char> crc = Modbus::CRC_16(Code_RTU, sizeof(Code_RTU));

		char msg[11] = {
						Code_RTU[0],                //addr
						Code_RTU[1],	            //write command
						Code_RTU[2],Code_RTU[3],	//registor
						Code_RTU[4],Code_RTU[5],	//length
						Code_RTU[6],                //length 2
						Code_RTU[7],Code_RTU[8],    //Data
						crc[0],crc[1]				//CRC
                        };

	return res;
}

std::vector<char> Modbus_Serial::Send_Request(unsigned char* message)
{
	return std::vector<char>();
}


void Modbus_Serial::Change_address(unsigned char corrent, unsigned char NEW) {}
