#include "Utilities.h"

#include <string>
#include <vector>

#include <iostream>
#include <cstdint>
#include <cstring>

float Utilities::byte_to_float(const unsigned char* bt)
{
	const unsigned char hex[4] = {	bt[3],	bt[2],	bt[1],	bt[0]	};
	float f;
	memcpy(&f, &hex, sizeof(float));
	return f;
}


std::vector<unsigned char> Utilities::str_to_char_V(std::string source)
{
	std::vector<unsigned char> res;
	for (int i = 0; i < source.length(); i++) {
		res.push_back((char)source.at(i));
	}
	return res;
}


std::string Utilities::char_V_to_str(std::vector<unsigned char> source)
{
	std::string res;
	for (int i = 0; i < source.capacity(); i++) {

		res += source[i];
	}
	return res;
}

std::vector<std::string> Utilities::splitString(const std::string& input, int chunkSize) {
    std::vector<std::string> chunks;
    int length = input.length();
    int startIndex = 0;

    while (startIndex < length) {
        int endIndex = startIndex + chunkSize;
        if (endIndex > length)
            endIndex = length;

        chunks.push_back(input.substr(startIndex, endIndex - startIndex));
        startIndex = endIndex;
    }

    return chunks;
}

std::string Utilities::base64_encode(const std::string &in) {

  std::string out;

  int val = 0, valb = -6;
  for (u_char c : in) {
    val = (val << 8) + c;
    valb += 8;
    while (valb >= 0) {
      out.push_back("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"[(val>>valb)&0x3F]);
      valb -= 6;
    }
  }
  if (valb>-6) out.push_back("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"[((val<<8)>>(valb+8))&0x3F]);
  while (out.size()%4) out.push_back('=');
  return out;
}

std::string Utilities::base64_decode(const std::string &in) {

  std::string out;

  std::vector<int> T(256,-1);
  for (int i=0; i<64; i++){
    T["ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"[i]] = i;
  }

  int val=0, valb=-8;
  for (u_char c : in) {
    if (T[c] == -1) break;
    val = (val << 6) + T[c];
    valb += 6;
    if (valb >= 0) {
      out.push_back(char((val>>valb)&0xFF));
      valb -= 8;
    }
  }
  return out;
}

std::string Utilities::CalculateMD5(const std::string& input) {
    CryptoPP::MD5 hash;
    unsigned char digest[CryptoPP::MD5::DIGESTSIZE];

    hash.CalculateDigest(digest, (const unsigned char*)input.c_str(), input.length());

    CryptoPP::HexEncoder encoder;
    std::string output;
    encoder.Attach(new CryptoPP::StringSink(output));
    encoder.Put(digest, sizeof(digest));
    encoder.MessageEnd();

    return output;
}


std::string Utilities::base32_encode(const std::string& input) {
    const std::string base32_chars = base64_decode("QUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVoyMzQ1Njc=");
    std::string output;
    int buffer = input[0];
    int next = 1;
    int bitsLeft = 8;
    while (bitsLeft > 0 || next < input.length()) {
        if (bitsLeft < 5) {
            if (next < input.length()) {
                buffer <<= 8;
                buffer |= input[next++] & 0xFF;
                bitsLeft += 8;
            } else {
                int pad = 5 - bitsLeft;
                buffer <<= pad;
                bitsLeft += pad;
            }
        }
        int index = 0x1F & (buffer >> (bitsLeft - 5));
        output.push_back(base32_chars[index]);
        bitsLeft -= 5;
    }
    while (output.size() % 8 != 0) {
        output.push_back('=');
    }
    return output;
}

std::string Utilities::EncryptData(const std::string &plainText, const std::string &publicKeyStr) {
    CryptoPP::StringSource publicKeyStrSource(publicKeyStr, true, new CryptoPP::Base64Decoder);
    CryptoPP::RSA::PublicKey publicKey;
    publicKey.Load(publicKeyStrSource);

    std::string cipherText;
    CryptoPP::RSAES_OAEP_SHA_Encryptor encryptor(publicKey);

    CryptoPP::AutoSeededRandomPool rng;
    CryptoPP::StringSource(plainText, true, new CryptoPP::PK_EncryptorFilter(rng, encryptor, new CryptoPP::StringSink(cipherText)));

    return cipherText;
}

std::string Utilities::decryptRSA(const std::string& encryptedMessage, std::string privateKeyString) {
    CryptoPP::StringSource privateKeyStrSource(privateKeyString, true, new CryptoPP::Base64Decoder);
    CryptoPP::RSA::PrivateKey privateKey;
    privateKey.Load(privateKeyStrSource);

    std::string decryptedMessage;
    CryptoPP::RSAES_OAEP_SHA_Decryptor decryptor(privateKey);

    CryptoPP::AutoSeededRandomPool rng;
    CryptoPP::StringSource(encryptedMessage, true, new CryptoPP::PK_DecryptorFilter(rng, decryptor, new CryptoPP::StringSink(decryptedMessage)));

    return decryptedMessage;
}

void Utilities::testKeyGeneration() {
    CryptoPP::AutoSeededRandomPool rng;
    CryptoPP::InvertibleRSAFunction params;
    params.GenerateRandomWithKeySize(rng, 2048);

    CryptoPP::RSA::PrivateKey privateKey(params);
    CryptoPP::RSA::PublicKey publicKey(params);

    std::string publicKeyStr;
    CryptoPP::Base64Encoder publicKeySink(new CryptoPP::StringSink(publicKeyStr));
    publicKey.DEREncode(publicKeySink);
    publicKeySink.MessageEnd();

    std::string privateKeyStr;
    CryptoPP::Base64Encoder privateKeySink(new CryptoPP::StringSink(privateKeyStr));
    privateKey.DEREncode(privateKeySink);
    privateKeySink.MessageEnd();

    std::cout << publicKeyStr << "\n";
    std::cout << privateKeyStr << "\n";
    std::cout << "Generated! Now testing:\n";

    publicKeyStr = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA4nN92giv0RUu8o1FnSJo tVLb6H9BGxI1VPYO+QGxTmIWLPCXvQN3+j2jBeYVksCLjKAmtjo1kk9jorN6TvDm zCnPxmz1TxCdHWRGzLWsx+KxmHkMCGZ55M4dUqB7vjN/DAwDC9/nvWZOQ36EZ3Yi f7g8Szt8edSOnZT4Swi54Un5FzzqiTqnlwCUxMvzHrT6xPqrZA7PdUWsE5+zOmex 8LTV5wvLcQG9rDZCc0JvMBAug+n122l46vHx9yV+EOZRk2urV6NYnKpm3AQv7rUR YNiLgmls2YQvOKb6pOcytayrJKeiPs6ZSuPJ76kZ0eB18fvTECyw/GoDEDrmT+bk wQIDAQAB";
    privateKeyStr= "MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQDic33aCK/RFS7y jUWdImi1Utvof0EbEjVU9g75AbFOYhYs8Je9A3f6PaMF5hWSwIuMoCa2OjWST2Oi s3pO8ObMKc/GbPVPEJ0dZEbMtazH4rGYeQwIZnnkzh1SoHu+M38MDAML3+e9Zk5D foRndiJ/uDxLO3x51I6dlPhLCLnhSfkXPOqJOqeXAJTEy/MetPrE+qtkDs91RawT n7M6Z7HwtNXnC8txAb2sNkJzQm8wEC6D6fXbaXjq8fH3JX4Q5lGTa6tXo1icqmbc BC/utRFg2IuCaWzZhC84pvqk5zK1rKskp6I+zplK48nvqRnR4HXx+9MQLLD8agMQ OuZP5uTBAgMBAAECggEARMnYfRcOcXEB5eRMNUNyk0IsUx/04whQ8xIb0kBVX/4j xlr/fQdEtttqXixaeU3MFle/6rMb+unq1k225awAMByzZQ9MJUxirb78UssNRVrz n+GFajfW505FUgg2Dr0N5tbvRfgqKTqeo5oXFmaobCvHBQN4+Hk9KVlLY1+vN2Py xw2Xj+5nKhTFTo9F8kf7NieWQTzehO8OoERV7Uum5hmrBX8ocIKS5pnFQavJ/m30 wmr5jLZT1Ej/KfSy1wsi+u3V1Z5D3g/d5ZQXcvRiy68uAhMLkQXjkNaOlHx2SPdS W8vR/3RMYu7TRhZsJv9Z92KA8yFnkpR1xYf9ji8uwQKBgQD6RMnwzp3niNc6c7qA 5JdLbOhHxuq4TKNIbvWf0zA+PrNSg5nD7BIUobFd7K0Q7ouQAijGsiZzEJ5sFwSV wlviLNFB5V6Pb0FM5fdlfZjsefHrpFleozOnrvXRsoV9Qn6MQ5f1PiYWSF7uasDz BKM2VadhNfpxrnmRyPrMwK9/HQKBgQDnoxI9tWRV/J9bMx/ktHV30QPGnmMAJLRy +uKt5dVO8nLddvabqTYv/uLELeSwECO5GEL1jmNEQ2aPw8nq/B0oZEctenIiQuoa 3k/nAFzuiFXB2dTUtIVzPJzZl6jpsO9TQMG57Cgt8Y4WdCsKsvYmk8kMFvbNoTb1 ItyvQ3DW9QKBgFZLve5A8IXT05MeMKMdL2YcqYOGfY0LMApb6Gox4iK0cBT1t+Gs 1xcyIfynDY4XExyXAgRxjXyDsHzI+xXArPoyRf2Y36BJ1pRzf3kJc9+mtNpyEzbk w30AgVbLXegxM32eGRnBUlTAo6tGOD4TzUuBAXQtrqvgY573VDOiBWGpAoGASOBy Xb3TGoaHcH8OOrtX9eFpybSNOz9REpfCd6nGybbX0ruZ7PF43fLYT5aMy6PYSWTL tEwfCRwXiYW04lx9o/agujs663KYCuoEw43GrzlvmbS6FE3TaqUYSBFCEHwdX9kQ 2jjlj0bfSEs2O4CAlzSJ3WbgMWPWUZutSOrz9n0CgYBrL2gz2G60ZF9zjfexXyQd GFC4znVlWbn5ZXWFqC0gKSX3Gb1+9lr4J63sPFT6uqCU9jQd9o5WusEDXAvQ2/W6 zfO4YwZD7X96dpLHgVk9sYdZIDnaSp9KfIVoxOHmBEF2SUjdns2XisbyICzLA+1t rCedLYswPygvolTXsLOB0w==";

    // Test key pair
    std::string testString = "test_keys\n";
    std::string encrypted = EncryptData(testString, publicKeyStr);
    std::string decrypted = decryptRSA(encrypted, privateKeyStr);

    std::cout << encrypted << "\n";
    std::cout << decrypted << "\n";

}
