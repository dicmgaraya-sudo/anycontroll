#ifndef STATUS_REPORTER_H
#define STATUS_REPORTER_H

#include <string>

struct HttpResult {
	bool ok = false;
	long http_code = 0;
	long latency_ms = 0;
	long curl_code = 0;
	std::string url;
	std::string peer;
	std::string curl_error;
	std::string redirect_url;
	std::string body;
};

class Status_reporter {
public:
	static HttpResult http_post(const std::string& data, const std::string& destination, const std::string& content_type = "");
	static void queue_frame(const std::string& payload);
	static bool flush_pending_frames(const std::string& destination);
	static std::string endpoint_url(const std::string& filename);
	static std::string host_name();
	static std::string brief_detail(const HttpResult& result);
	static void log(const std::string& line);
	static const std::string& last_line();
	static void send_status(bool modbus_ok,
		int device_count,
		bool mea_ok,
		const std::string& mea_detail,
		long mea_latency_ms);
	static void send_event(const std::string& component,
		const std::string& status,
		const std::string& event_code,
		const std::string& message);
};

#endif
