#include <iostream>
#include <vector>
#include <thread>
#include <chrono>
#include <future>
#include <cstring>
#include <cerrno>
#include <fcntl.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <unistd.h>
#include "TCP_Conn.h"

bool TCP_Conn::wait_response;
int32_t TCP_Conn::trys_to_connect = 1;
int32_t TCP_Conn::reconnect_wait = 10 * 1000;

bool TCP_Conn::Tcp_Start() {
    if (!create_socket()) {
        std::cout << "Socket invalid!\n" << std::flush;
        return false;
    }

    std::cout << "Conectando em " << adaptor_IP << ":" << port << "\n" << std::flush;

    sockaddr_in hint{};
    hint.sin_family = AF_INET;
    hint.sin_port = htons(port);
    if (inet_pton(AF_INET, adaptor_IP.c_str(), &hint.sin_addr) != 1) {
        std::cerr << "IP invalido: " << adaptor_IP << "\n" << std::flush;
        close(sock);
        return false;
    }

    const int flags = fcntl(sock, F_GETFL, 0);
    if (flags < 0 || fcntl(sock, F_SETFL, flags | O_NONBLOCK) < 0) {
        std::cerr << "Failed to set nonblocking socket\n" << std::flush;
        close(sock);
        return false;
    }

    int so_error = 0;
    const int connResult = connect(sock, (sockaddr *)&hint, sizeof(hint));
    if (connResult == -1 && errno != EINPROGRESS) {
        so_error = errno;
    } else if (connResult != 0) {
        fd_set write_fds;
        FD_ZERO(&write_fds);
        FD_SET(sock, &write_fds);
        timeval timeout;
        timeout.tv_sec = 5;
        timeout.tv_usec = 0;
        const int selected = select(sock + 1, nullptr, &write_fds, nullptr, &timeout);
        if (selected == 0) {
            so_error = ETIMEDOUT;
        } else if (selected < 0) {
            so_error = errno;
        } else {
            socklen_t so_len = sizeof(so_error);
            getsockopt(sock, SOL_SOCKET, SO_ERROR, &so_error, &so_len);
        }
    }

    if (so_error != 0 || fcntl(sock, F_SETFL, flags) < 0) {
        std::cerr << "Failed to connect to " << adaptor_IP << ":" << port;
        if (so_error == ETIMEDOUT) {
            std::cerr << " (timeout 5s)";
        }
        std::cerr << "\n" << std::flush;
        close(sock);
        std::cout << "Attempt: " << trys_to_connect << "\n" << std::flush;
        trys_to_connect++;
        std::this_thread::sleep_for(std::chrono::milliseconds(reconnect_wait));
        return false;
    }

    return true;
}

bool TCP_Conn::restart_conn() {
    close(sock);
    return Tcp_Start();
}

bool TCP_Conn::create_socket() {
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == 0) return false;

    return true;
}

std::vector<char> TCP_Conn::SendBytes(const unsigned char *msg, size_t length) {
    const int sendResult = send(sock, msg, length, 0);

    std::cout << std::dec << "->";
    for (int i = 0; i < length; i++) {
        std::cout << std::hex << (short)msg[i] << " ";
    }
    std::cout << std::dec << "\n";

    if (sendResult != -1) {
        byte buf[16];
        memset(&buf, (byte)0, sizeof(buf));

        std::promise<void> exitSignal;
        const std::future<void> futureObj = exitSignal.get_future();
        std::thread con_thread(recv, sock, buf, sizeof(buf), 0);
        std::this_thread::sleep_for(std::chrono::milliseconds(500));

        if (con_thread.joinable()) con_thread.detach();

        exitSignal.set_value();

        bool bytesReceived = false;

        for (int i = 0; i < 16; i++)
            if (buf[i] != 0) {
                bytesReceived = true;
                break;
            }

        if (bytesReceived) {
            std::cout << "<- ";
            std::vector<char> response;

            for (int i = 0; i < sizeof(buf); i++){
                response.push_back(buf[i]);
                std::cout << std::hex << (short)buf[i] << " ";
            }
            std::cout << "\n";
            return response;

        } else if (wait_response) {
            std::cout << "Connection lost?\n";

            std::cout << "Attempt: " << trys_to_connect << "\n";
            trys_to_connect++;
            std::this_thread::sleep_for(std::chrono::milliseconds(reconnect_wait));

            while (!restart_conn()) {}
            return SendBytes(msg, length);
        }
    }
    return std::vector<char>();
}
