#include "Status_reporter.h"

#include "Config_maneger.h"

#include <chrono>
#include <cstddef>
#include <cstdio>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <vector>
#include <curl/curl.h>
#include <unistd.h>

#include "nlohmann/json.hpp"

namespace {
	size_t write_callback(char* contents, size_t size, size_t nmemb, char* buffer_in) {
		((std::string*)buffer_in)->append((char*)contents, size * nmemb);
		return size * nmemb;
	}

	std::string g_last_line;
	bool g_log_opened = false;
	const char* spool_path = "pending_frames.spool";
	const char* spool_tmp_path = "pending_frames.spool.tmp";

	std::vector<std::string> read_spool_lines() {
		std::vector<std::string> lines;
		std::ifstream in(spool_path);
		if (!in) {
			return lines;
		}
		std::string line;
		while (std::getline(in, line)) {
			if (!line.empty() && line.back() == '\r') {
				line.pop_back();
			}
			if (!line.empty()) {
				lines.push_back(line);
			}
		}
		return lines;
	}

	bool write_spool_lines(const std::vector<std::string>& lines) {
		if (lines.empty()) {
			std::remove(spool_tmp_path);
			std::remove(spool_path);
			return true;
		}
		{
			std::ofstream out(spool_tmp_path, std::ios::trunc);
			if (!out) {
				return false;
			}
			for (const std::string& line : lines) {
				out << line << '\n';
			}
			out.flush();
			if (!out) {
				return false;
			}
		}
		return std::rename(spool_tmp_path, spool_path) == 0;
	}

	bool looks_like_html(const std::string& body) {
		return body.find("<!DOCTYPE") != std::string::npos
			|| body.find("<html") != std::string::npos
			|| body.find("<HTML") != std::string::npos;
	}

	std::string one_line(std::string text) {
		for (char& c : text) {
			if (c == '\n' || c == '\r' || c == '\t') {
				c = ' ';
			}
		}
		const size_t start = text.find_first_not_of(' ');
		if (start == std::string::npos) {
			return "";
		}
		const size_t end = text.find_last_not_of(' ');
		return text.substr(start, end - start + 1);
	}

	bool body_accepted(const std::string& body) {
		return one_line(body) == "OK";
	}

	std::string form_escape(const std::string& value) {
		std::string out;
		out.reserve(value.size() * 3);
		for (unsigned char c : value) {
			if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.' || c == '~') {
				out.push_back(static_cast<char>(c));
			} else if (c == ' ') {
				out.push_back('+');
			} else {
				static const char* hex = "0123456789ABCDEF";
				out.push_back('%');
				out.push_back(hex[c >> 4]);
				out.push_back(hex[c & 0x0F]);
			}
		}
		return out;
	}

	std::string form_field(const std::string& key, const std::string& value, bool first) {
		std::string out = first ? "" : "&";
		out += form_escape(key);
		out += "=";
		out += form_escape(value);
		return out;
	}

	std::string clip(const std::string& text, size_t limit) {
		if (text.size() <= limit) {
			return text;
		}
		return text.substr(0, limit) + "...";
	}

	std::string tag_text(const std::string& body, const std::string& open, const std::string& close) {
		const size_t start = body.find(open);
		if (start == std::string::npos) {
			return "";
		}
		const size_t from = start + open.size();
		const size_t end = body.find(close, from);
		if (end == std::string::npos) {
			return "";
		}
		return one_line(body.substr(from, end - from));
	}

	std::string body_excerpt(const std::string& body) {
		if (body.empty()) {
			return "";
		}
		if (looks_like_html(body)) {
			const std::string title = tag_text(body, "<title>", "</title>");
			const std::string h1 = tag_text(body, "<h1>", "</h1>");
			std::string excerpt = "html";
			if (!title.empty()) {
				excerpt += " title=\"" + clip(title, 120) + "\"";
			}
			if (!h1.empty() && h1 != title) {
				excerpt += " h1=\"" + clip(h1, 120) + "\"";
			}
			if (title.empty() && h1.empty()) {
				excerpt += " len=" + std::to_string(body.size());
			}
			return excerpt;
		}
		return clip(one_line(body), 400);
	}

	std::string timestamp() {
		const std::time_t now = std::time(nullptr);
		std::tm tm_buf{};
		localtime_r(&now, &tm_buf);
		std::ostringstream out;
		out << std::put_time(&tm_buf, "%Y-%m-%d %H:%M:%S");
		return out.str();
	}
}

HttpResult Status_reporter::http_post(const std::string& data, const std::string& destination, const std::string& content_type) {
	HttpResult result;
	result.ok = false;
	result.http_code = 0;
	result.latency_ms = 0;

	result.url = destination;
	CURL* curl = curl_easy_init();
	if (!curl) {
		result.curl_code = -1;
		result.curl_error = "curl_easy_init failed";
		return result;
	}

	const auto started = std::chrono::steady_clock::now();
	char errbuf[CURL_ERROR_SIZE];
	errbuf[0] = '\0';
	struct curl_slist* hs = NULL;
	if (!content_type.empty()) {
		const std::string header = "Content-Type: " + content_type;
		hs = curl_slist_append(hs, header.c_str());
	}
	curl_easy_setopt(curl, CURLOPT_URL, destination.c_str());
	curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, errbuf);
	curl_easy_setopt(curl, CURLOPT_HTTPHEADER, hs);
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data.c_str());
	curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, data.length());
	curl_easy_setopt(curl, CURLOPT_POST, 1L);
	curl_easy_setopt(curl, CURLOPT_TIMEOUT, 30L);
	curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 10L);
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, &result.body);

	const CURLcode res = curl_easy_perform(curl);
	const auto ended = std::chrono::steady_clock::now();
	result.latency_ms = std::chrono::duration_cast<std::chrono::milliseconds>(ended - started).count();

	result.curl_code = static_cast<long>(res);
	if (res == CURLE_OK) {
		curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &result.http_code);
		result.ok = result.http_code >= 200 && result.http_code < 300;
		char* redirect = nullptr;
		if (curl_easy_getinfo(curl, CURLINFO_REDIRECT_URL, &redirect) == CURLE_OK && redirect != nullptr) {
			result.redirect_url = redirect;
		}
	} else {
		result.curl_error = errbuf[0] != '\0' ? std::string(errbuf) : curl_easy_strerror(res);
	}

	char* ip = nullptr;
	if (curl_easy_getinfo(curl, CURLINFO_PRIMARY_IP, &ip) == CURLE_OK && ip != nullptr && ip[0] != '\0') {
		result.peer = ip;
	}

	curl_slist_free_all(hs);
	curl_easy_cleanup(curl);
	return result;
}

void Status_reporter::queue_frame(const std::string& payload) {
	if (payload.empty()) {
		return;
	}
	std::ofstream out(spool_path, std::ios::app);
	if (!out) {
		log("frame spool: nao foi possivel abrir pending_frames.spool");
		return;
	}
	out << payload << '\n';
	out.flush();
	log("frame queued bytes=" + std::to_string(payload.size()));
}

bool Status_reporter::flush_pending_frames(const std::string& destination) {
	const std::vector<std::string> lines = read_spool_lines();
	if (lines.empty()) {
		return true;
	}

	size_t sent = 0;
	for (; sent < lines.size(); ++sent) {
		const HttpResult result = http_post(lines[sent], destination);
		if (!result.ok) {
			log("frame spool retry FAIL " + brief_detail(result));
			break;
		}
	}

	const std::vector<std::string> remaining(lines.begin() + static_cast<std::ptrdiff_t>(sent), lines.end());
	const bool saved = write_spool_lines(remaining);
	if (!saved) {
		log("frame spool: nao foi possivel regravar pending_frames.spool");
	}
	log("frame spool flush sent=" + std::to_string(sent) + " left=" + std::to_string(remaining.size()));
	return saved && remaining.empty();
}

void Status_reporter::log(const std::string& line) {
#ifdef NDEBUG
	(void)line;
#else
	const std::string stamped = timestamp() + " " + line;
	g_last_line = stamped;
	std::cout << stamped << "\n" << std::flush;
	std::ofstream out("status_report.log", std::ios::app);
	if (!out) {
		std::cout << timestamp() << " status log: nao foi possivel abrir status_report.log\n" << std::flush;
		return;
	}
	if (!g_log_opened) {
		out << timestamp() << " status log: gravando em status_report.log\n";
		g_log_opened = true;
	}
	out << stamped << "\n";
#endif
}

const std::string& Status_reporter::last_line() {
	return g_last_line;
}

std::string Status_reporter::brief_detail(const HttpResult& result) {
	std::string detail;
	if (!result.curl_error.empty()) {
		detail = "curl=" + std::to_string(result.curl_code) + " " + result.curl_error;
	}
	if (!result.redirect_url.empty()) {
		if (!detail.empty()) {
			detail += " ";
		}
		detail += "redirect=" + result.redirect_url;
	}
	const std::string excerpt = body_excerpt(result.body);
	if (!excerpt.empty()) {
		if (!detail.empty()) {
			detail += " ";
		}
		detail += "body=" + excerpt;
	}
	if (detail.empty()) {
		return "sem corpo e sem erro curl";
	}
	return detail;
}

std::string failure_reason(const HttpResult& result) {
	if (result.curl_code == -1) {
		return "libcurl nao inicializou";
	}
	if (!result.curl_error.empty()) {
		return result.curl_error;
	}
	if (!result.redirect_url.empty() || (result.http_code >= 300 && result.http_code < 400)) {
		return "redirect nao seguido";
	}
	if (result.http_code == 0) {
		return "sem codigo HTTP";
	}
	if (result.http_code >= 400) {
		return "HTTP " + std::to_string(result.http_code);
	}
	if (result.ok && result.body.empty()) {
		return "HTTP 200 com corpo vazio";
	}
	if (result.ok) {
		return "aceito";
	}
	return "resposta rejeitada";
}

std::string post_summary(const char* kind, const HttpResult& result) {
	std::ostringstream out;
	out << kind << " " << (result.ok ? "OK" : "FAIL")
		<< " reason=\"" << failure_reason(result) << "\""
		<< " url=" << result.url
		<< " http=" << result.http_code
		<< " curl=" << result.curl_code
		<< " latency_ms=" << result.latency_ms;
	if (!result.peer.empty()) {
		out << " peer=" << result.peer;
	}
	out << " " << Status_reporter::brief_detail(result);
	return out.str();
}

std::string Status_reporter::endpoint_url(const std::string& filename) {
	const std::string& base = Config_maneger::PHP_Server_Addr;
	const size_t pos = base.find_last_of('/');
	if (pos == std::string::npos) {
		return filename;
	}
	return base.substr(0, pos + 1) + filename;
}

std::string Status_reporter::host_name() {
	char buf[256];
	if (gethostname(buf, sizeof(buf)) == 0) {
		buf[sizeof(buf) - 1] = '\0';
		return std::string(buf);
	}
	return "unknown";
}

void Status_reporter::send_status(bool modbus_ok,
	bool serial_present,
	int device_count,
	bool mea_ok,
	const std::string& mea_detail,
	long mea_latency_ms) {
	nlohmann::json payload;
	payload["unique_ID"] = Config_maneger::Setup_ID;
	payload["host"] = host_name();
	payload["app_version"] = "anycontroller";

	nlohmann::json components = nlohmann::json::array();

	components.push_back({
		{"name", "host"},
		{"status", "ok"},
		{"detail", host_name()}
	});

	components.push_back({
		{"name", "network"},
		{"status", mea_ok ? "ok" : "warn"},
		{"detail", mea_ok ? "rota ate MEA responsiva" : "falha de rede ou MEA"}
	});

	components.push_back({
		{"name", "modbus_tcp"},
		{"status", modbus_ok ? "ok" : "fail"},
		{"detail", modbus_ok
			? ("adaptor " + Config_maneger::adaptor_Addr + ":502")
			: ("sem resposta em " + Config_maneger::adaptor_Addr + ":502")}
	});

	components.push_back({
		{"name", "modbus_serial"},
		{"status", serial_present ? "ok" : "offline"},
		{"detail", serial_present ? "porta serial detectada" : "sem /dev/ttyUSB* ou ttyS*"}
	});

	std::string meter_status = "ok";
	std::string meter_detail = std::to_string(device_count) + " medidor(es)";
	if (device_count <= 0) {
		meter_status = modbus_ok ? "warn" : "fail";
		meter_detail = "nenhum medidor encontrado";
	}
	components.push_back({
		{"name", "meter"},
		{"status", meter_status},
		{"detail", meter_detail},
		{"meta", {{"count", device_count}}}
	});

	components.push_back({
		{"name", "mea"},
		{"status", mea_ok ? "ok" : "fail"},
		{"detail", mea_detail},
		{"latency_ms", mea_latency_ms}
	});

	payload["components"] = components;

	const std::string body = form_field("unique_ID", Config_maneger::Setup_ID, true)
		+ form_field("host", host_name(), false)
		+ form_field("app_version", "anycontroller", false)
		+ form_field("components", components.dump(), false);
	const std::string url = endpoint_url("save_device_status.php");
	log("status ATTEMPT url=" + url
		+ " unique_ID=\"" + Config_maneger::Setup_ID + "\""
		+ " bytes=" + std::to_string(body.size())
		+ " modbus=" + std::string(modbus_ok ? "ok" : "fail")
		+ " serial=" + std::string(serial_present ? "ok" : "offline")
		+ " meters=" + std::to_string(device_count)
		+ " mea=" + std::string(mea_ok ? "ok" : "fail")
		+ " mea_detail=\"" + clip(one_line(mea_detail), 160) + "\"");
	if (url.find("http://") != 0 && url.find("https://") != 0) {
		log("status URL invalida base=\"" + Config_maneger::PHP_Server_Addr + "\" derivada=\"" + url + "\"");
	}

	HttpResult result = http_post(body, url, "application/x-www-form-urlencoded");
	if (result.ok && !body_accepted(result.body)) {
		result.ok = false;
	}
	log(post_summary("status", result) + " unique_ID=\"" + Config_maneger::Setup_ID + "\"");
	if (!result.ok) {
		log("status FAIL payload=" + clip(one_line(body), 500));
	}
}

void Status_reporter::send_event(const std::string& component,
	const std::string& status,
	const std::string& event_code,
	const std::string& message) {
	const std::string body = form_field("unique_ID", Config_maneger::Setup_ID, true)
		+ form_field("component", component, false)
		+ form_field("status", status, false)
		+ form_field("event_code", event_code, false)
		+ form_field("message", message, false);
	const std::string url = endpoint_url("save_device_event.php");
	log("event ATTEMPT code=" + event_code + " url=" + url + " unique_ID=\"" + Config_maneger::Setup_ID + "\"");
	HttpResult result = http_post(body, url, "application/x-www-form-urlencoded");
	if (result.ok && !body_accepted(result.body)) {
		result.ok = false;
	}
	log(post_summary("event", result) + " code=" + event_code);
}
