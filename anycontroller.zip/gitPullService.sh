#!/bin/bash

# Determine the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" &> /dev/null && pwd)"
# Extract folder name for service naming
FOLDER_NAME=$(basename "$SCRIPT_DIR")
# Define service and timer names with folder name
SERVICE_NAME="gitPull-$FOLDER_NAME.service"
TIMER_NAME="gitPull-$FOLDER_NAME.timer"

# Path to the gitPull.sh script
GIT_PULL_SCRIPT="$SCRIPT_DIR/gitPull.sh"

# Log file path in the same directory
LOG_FILE="$SCRIPT_DIR/log.txt"

# Check if the gitPull.sh script exists
if [ ! -f "$GIT_PULL_SCRIPT" ]; then
    echo "Error: gitPull.sh script not found at $GIT_PULL_SCRIPT"
    exit 1
fi

# Create or update the systemd service file for gitPull.sh
echo "Creating or updating systemd service file for $SERVICE_NAME..."
sudo tee "/etc/systemd/system/$SERVICE_NAME" <<EOF
[Unit]
Description=Git Pull Service for $FOLDER_NAME

[Service]
ExecStart=/bin/bash -c '"$GIT_PULL_SCRIPT" || echo "fail to run gitPull error: \$?" >> "$LOG_FILE"'

[Install]
WantedBy=multi-user.target
EOF

# Create or update the systemd timer file for gitPull.sh
echo "Creating or updating systemd timer file for $TIMER_NAME..."
sudo tee "/etc/systemd/system/$TIMER_NAME" <<EOF
[Unit]
Description=Run gitPull service every hour

[Timer]
OnCalendar=hourly
Persistent=true

[Install]
WantedBy=timers.target
EOF

# Reload systemd to apply new changes
echo "Reloading systemd daemon..."
sudo systemctl daemon-reload

# Enable and start the timer
echo "Enabling and starting the timer $TIMER_NAME..."
sudo systemctl enable $TIMER_NAME
sudo systemctl start $TIMER_NAME

# Inform the user that the script setup is complete
echo "Systemd timer setup for $TIMER_NAME is complete."
