#ifndef MODBUS_TCP_H
#define MODBUS_TCP_H

#include "TCP_Conn.h"
#include "MODBUS.h"

class Modbus_TCP: public Modbus
{
	public:
		TCP_Conn tcp_conn = TCP_Conn("",0);
		static bool MODBUS_TCP_Format;
		static bool MODBUS_RTU_Format;
		Modbus_TCP(const int f_time, const std::string IP, const int prt);

		std::vector<char> Read_from_Device(const byte device_ID, const  byte* reg_addr, const byte* length);
		std::vector<char> Write_to_Device(byte device_ID, byte* reg_addr, byte* length, const byte* data);
		void Change_address(byte corrent, byte NEW);
    bool Start_conn();

	private:
		std::vector<char> Send_Request(byte* message);//sends request to RS485 device
};
#endif
