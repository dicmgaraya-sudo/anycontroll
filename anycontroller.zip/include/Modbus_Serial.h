#ifndef MODBUS_SERIAL_H
#define MODBUS_SERIAL_H


#include "serial_conn.h"
#include "MODBUS.h"

class Modbus_Serial: public Modbus
{
    public:
		std::vector<char> Read_from_Device(const unsigned char device_ID, const  unsigned char* reg_addr, const unsigned char* length);
		std::vector<char> Write_to_Device(unsigned char device_ID, unsigned char* reg_addr, unsigned char* length, const unsigned char* data);
		void Change_address(unsigned char corrent, unsigned char NEW);
		void Start_conn();

	private:
		std::vector<char> Send_Request(unsigned char* message);//sends request to RS485 device
};

#endif // MODBUS_SERIAL_H
