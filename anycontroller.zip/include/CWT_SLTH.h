#ifndef CWT_SLTH_H
#define CWT_SLTH_H

#include "Medidor.h"
class CWT_SLTH:public Medidor
{
    public:
        CWT_SLTH();

        int GetType(int addr) const override;

    //private:
        static bool registered;
};

#endif // CWT_SLTH_H
