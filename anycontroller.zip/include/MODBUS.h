#ifndef MODBUS_H
#define MODBUS_H

#include <string>
#include <vector>
#include "Utilities.h"

class Modbus
{
	public:

		virtual std::vector<char> Read_from_Device(const unsigned char device_ID, const unsigned char* reg_addr, const unsigned char* length) = 0;
		virtual std::vector<char> Write_to_Device(unsigned char device_ID, unsigned char* reg_addr, unsigned char* length, const unsigned char* data) = 0;

		virtual void Change_address(unsigned char corrent, unsigned char NEW)=0;//change modbus address

		static std::vector<float> process_response(std::vector<char> response);
		static std::vector<unsigned char> CRC_16(unsigned char* buf, int len);
		static std::vector<char> separete_data(std::vector<char> vec, short data_len, short cut);

	private:
		virtual std::vector<char> Send_Request(unsigned char* message) = 0;//sends request to RS485 device
};

#endif // MODBUS_H
