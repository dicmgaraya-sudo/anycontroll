#ifndef CHINT_BIFASE_H
#define CHINT_BIFASE_H


#include "Medidor.h"

class Chint_BiFase:public Medidor
{
	public:
		Chint_BiFase();

        int GetType(int addr) const override;

        // Method to register this derived class with the base class
        static const bool registered;
    //private:


};

#endif // CHINT_BIFASE_H
