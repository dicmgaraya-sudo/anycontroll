#ifndef CHINT_TRIFASE_H
#define CHINT_TRIFASE_H


#include "Medidor.h"

class Chint_TriFase :public Medidor
{
public:
	Chint_TriFase();
	//void GetMeter(FunctionType func, const std::string& name, int number, bool* result) override;

    int GetType(int addr) const override;

//private:
    static bool registered;
};



#endif // CHINT_TRIFASE_H
