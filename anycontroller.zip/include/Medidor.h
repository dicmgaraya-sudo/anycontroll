#ifndef MEDIDOR_H
#define MEDIDOR_H

#pragma once

#include <memory>

#include <vector>
#include <string>
#include <iostream>

#include "MODBUS.h"

struct Registor_data {
	std::string identifier;
	short addr;
	short length;
};

class Medidor
{
public:
	short addr;
	short d_type;
	std::vector<Registor_data> Registors;

	Registor_data Get_addr(std::string index);
	static bool Conection_test(short index);

    //AnySensor
    static std::shared_ptr<Medidor> GetNew(int Addr);
    static Modbus *modbusDevice;

//protected:
    static void RegisterType(std::function<std::shared_ptr<Medidor>()> creatorFunc, int type);

//private:

    virtual int GetType(int addr) const = 0;

    static std::vector<std::pair<std::function<std::shared_ptr<Medidor>()>, int>>& registeredTypes();

};

#endif // MEDIDOR_H
