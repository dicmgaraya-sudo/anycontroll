#ifndef SERIAL_CONN_H
#define SERIAL_CONN_H

#include <iostream>
#include <string>
#include <vector>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <glob.h>
#include <errno.h>
#include <cstring>
#include <sys/select.h>

#include "MODBUS.h"

//#define byte unsigned char

class serial_conn
{
    public:
        serial_conn();
        virtual ~serial_conn();

        static std::string serial_devices;
        static std::vector<std::string> getSerialPortList();
        static std::vector<char> SendBytes(const std::string &port, unsigned char* msg, short length);
        static bool checkSerialPortConnection(const std::string &port );
        static bool check_all_Ports();

    protected:

    private:
        static bool hand_shake();
};

#endif // SERIAL_CONN_H
