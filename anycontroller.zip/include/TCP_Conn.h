#ifndef TCP_CONN_H
#define TCP_CONN_H

#include <string>
#include <vector>
#include <algorithm>
#include <cstdint>

using byte = unsigned char;

class TCP_Conn {
public:
    TCP_Conn(std::string ip, uint16_t p) : adaptor_IP(ip), port(p) {}

    bool Tcp_Start();
    bool restart_conn();
    std::vector<char> SendBytes(const unsigned char *msg, size_t length);

    static bool wait_response;

private:
    bool create_socket();
    int sock;
    std::string adaptor_IP;
    uint16_t port;

    static int32_t trys_to_connect;
    static int32_t reconnect_wait;
};

#endif //TCP_CONN_H
