#ifndef CONFIG_MANEGER_H
#define CONFIG_MANEGER_H


#include <string>

class Config_maneger
{
	public:
		Config_maneger();

		static std::string adaptor_Addr;
		static std::string PHP_Server_Addr;
		static std::string Setup_ID;
};


#endif // CONFIG_MANEGER_H
