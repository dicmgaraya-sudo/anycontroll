#include "serial_conn.h"
#include "Modbus_Serial.h"

#define byte unsigned char

std::string serial_conn::serial_devices;

serial_conn::serial_conn()
{
    //ctor
}

serial_conn::~serial_conn()
{
    //dtor
}

namespace {
    void append_serial_matches(std::vector<std::string>& serialPorts, const char* pattern) {
        glob_t glob_result;
        memset(&glob_result, 0, sizeof(glob_result));
        const int rc = glob(pattern, GLOB_TILDE, NULL, &glob_result);
        if (rc != 0) {
            std::cout << "The length of the vector " << pattern << " is: 0" << std::endl;
            return;
        }

        std::cout << "The length of the vector " << pattern << " is: " << glob_result.gl_pathc << std::endl;
        for (size_t i = 0; i < glob_result.gl_pathc; ++i) {
            if (glob_result.gl_pathv[i] == NULL) {
                continue;
            }
            const std::string port = glob_result.gl_pathv[i];
            bool already_listed = false;
            for (const std::string& listed : serialPorts) {
                if (listed == port) {
                    already_listed = true;
                    break;
                }
            }
            if (!already_listed) {
                serialPorts.push_back(port);
            }
        }
        globfree(&glob_result);
    }
}

std::vector<std::string> serial_conn::getSerialPortList() {
    std::vector<std::string> serialPorts;
    append_serial_matches(serialPorts, "/dev/ttyS*");
    append_serial_matches(serialPorts, "/dev/ttyUSB*");
    return serialPorts;
}

bool serial_conn::checkSerialPortConnection(const std::string &port ) {

    int fileDescriptor = open(port.c_str(), O_RDWR | O_NOCTTY | O_NDELAY);

    if (fileDescriptor < 0) {
        int err = errno;
        std::cout << "Comunication not possible on port: " << port << std::endl;
        switch (err) {
            case EACCES:
                std::cout<<  "Permission denied to access the serial port."<< std::endl;
                break;
            case ENOENT:
                std::cout<<  "Serial port does not exist."<< std::endl;
                break;
            case EBUSY:
                std::cout<<  "Serial port is in use by another process."<< std::endl;
                break;
            case EINVAL:
                std::cout<<  "Invalid port path."<< std::endl;
                break;
            default:
                std::cout<<  "Unknown error (" + std::to_string(err) + "): " << std::endl;
                break;
        }
        return false;
    }

    close(fileDescriptor);
    serial_devices = port;
    if (hand_shake()) {
        return true;
    }
    serial_devices.clear();
    return false;
}

bool serial_conn::hand_shake(){
    Modbus_Serial MS = Modbus_Serial();
    const short addr = 0x2000;
    const short length = 2;

    for(short i = 1; i<240; i++){
        const std::vector<char> hold_data =  MS.Read_from_Device(i, (byte*)&addr, (byte*)&length);
        if (hold_data.size() < 4) {
            continue;
        }
        for(int j = 0; j < 4;j++){
            if(hold_data[j] != 0){
                std::cout<<"Encontrado em: "<< serial_devices<<std::endl;
                return true;
            }
        }
    }
    return false;
}

std::vector<char> serial_conn::SendBytes(const std::string &port, unsigned char* msg, short length){
    if (port.empty() || msg == nullptr || length <= 0) {
        return {};
    }

    std::cout << "Enviado "<<port<<":";
    for(short i = 0; i < length;++i){
        std::cout << std::hex << static_cast<int>(msg[i])<< " ";
    }
    std::cout << std::dec << std::endl;

    const int fileDescriptor = open(port.c_str(), O_RDWR | O_NOCTTY | O_NONBLOCK);
    if (fileDescriptor < 0) {
        std::cout << "Comunication not possible on port: " << port << " (" << strerror(errno) << ")" << std::endl;
        return {};
    }

    struct termios options;
    if (tcgetattr(fileDescriptor, &options) != 0) {
        std::cout << "Failed to read serial settings: " << strerror(errno) << std::endl;
        close(fileDescriptor);
        return {};
    }

    cfsetispeed(&options, B9600);
    cfsetospeed(&options, B9600);
    options.c_cflag |= (CLOCAL | CREAD);
    options.c_cflag &= ~PARENB;
    options.c_cflag &= ~CSTOPB;
    options.c_cflag &= ~CSIZE;
    options.c_cflag |= CS8;
    options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
    options.c_iflag &= ~(IXON | IXOFF | IXANY);
    options.c_oflag &= ~OPOST;
    if (tcsetattr(fileDescriptor, TCSANOW, &options) != 0) {
        std::cout << "Failed to apply serial settings: " << strerror(errno) << std::endl;
        close(fileDescriptor);
        return {};
    }

    if (fcntl(fileDescriptor, F_SETFL, 0) != 0) {
        std::cout << "Failed to set blocking mode: " << strerror(errno) << std::endl;
        close(fileDescriptor);
        return {};
    }

    const ssize_t written = write(fileDescriptor, msg, static_cast<size_t>(length));
    if (written != length) {
        std::cout << "Serial write failed: " << strerror(errno) << std::endl;
        close(fileDescriptor);
        return {};
    }

    usleep(100000);

    char raw[256];
    struct timeval timeout;
    timeout.tv_sec = 0;
    timeout.tv_usec = 300000;

    fd_set read_fds;
    FD_ZERO(&read_fds);
    FD_SET(fileDescriptor, &read_fds);

    const int select_result = select(fileDescriptor + 1, &read_fds, NULL, NULL, &timeout);
    if (select_result == 0) {
        std::cout << "Timeout: Sem dispositivo no endereço" << std::endl;
        close(fileDescriptor);
        return {};
    }
    if (select_result < 0 || !FD_ISSET(fileDescriptor, &read_fds)) {
        std::cout << "Error occurred during select: "<< strerror(errno)<< std::endl;
        close(fileDescriptor);
        return {};
    }

    const ssize_t bytesRead = read(fileDescriptor, raw, sizeof(raw));
    close(fileDescriptor);
    if (bytesRead <= 0) {
        if (bytesRead < 0) {
            std::cout << "Serial read failed: " << strerror(errno) << std::endl;
        }
        return {};
    }

    std::vector<char> buffer(raw, raw + bytesRead);
    std::cout << "Resposta:";
    for (char value : buffer) {
        std::cout << std::hex << static_cast<int>(static_cast<unsigned char>(value)) << " ";
    }
    std::cout << std::dec << std::endl;
    return buffer;
}

bool serial_conn::check_all_Ports() {
    std::vector<std::string> serialPorts = getSerialPortList();

    for (const std::string &port : serialPorts) {
        if (checkSerialPortConnection(port)){
            std::cout << port << std::endl;
            serial_devices = port;
            return true;
        }
    }
    return false;
}
