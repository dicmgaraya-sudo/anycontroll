#include "Config_maneger.h"

#include "Utilities.h"

#include <iostream>
#include <string>
#include <fstream>
#include <vector>

std::string Config_maneger::adaptor_Addr;
std::string Config_maneger::PHP_Server_Addr;
std::string Config_maneger::Setup_ID;

Config_maneger::Config_maneger() {

	std::string configs_tr = ""; //Data string holder

	std::fstream  configs_file("config.json", std::ios::in); //Prepare file to be read
	if (!configs_file.is_open()) {
		std::cout << "Fail to load the config.json file!\n";
		return;
	}
	//using namespace std;
	std::string configs_line;
	while (std::getline(configs_file, configs_line)) //Read  file string
		configs_tr += configs_line;

	size_t pos = 0;
	std::string delimiter = "\"";

	std::vector<std::string> data;

	while ((pos = configs_tr.find(delimiter)) != std::string::npos)//Run through all items in the string
	{
		data.push_back(configs_tr.substr(0, pos));
		configs_tr.erase(0, pos + delimiter.length());
	}
	//Store data at the static variables
	adaptor_Addr = data[3];
	PHP_Server_Addr = data[7];
	Setup_ID = data[11];

	configs_file.close();
}
