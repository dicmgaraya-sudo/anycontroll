#include "Chint_BiFase.h"


Chint_BiFase::Chint_BiFase(){
	Registors = {
		Registor_data{"volt",	0x2000,0x0002},
		Registor_data{"amps",	0x2002,0x0002},
		Registor_data{"power",	0x2008,0x0002},
		Registor_data{"FP",		0x200A,0x0002},
		Registor_data{"used",	0x4000,0x0002},
		Registor_data{"hertz",	0x200E,0x0002},
		Registor_data{"Bound",	0x000C,0x0001},
		Registor_data{"Device",	0x0006,0x0001}
	};
	d_type = 2;
}


const bool Chint_BiFase::registered = [] {
    std::cout <<"The number of itens is:"<<registeredTypes().size()<<"\n";
    Medidor::RegisterType([]() -> std::shared_ptr<Medidor> { return std::make_shared<Chint_BiFase>(); }, 2);
    std::cout <<"The number of itens is:"<<registeredTypes().size()<<"\n";
    return true;
}();



int Chint_BiFase::GetType(int addr) const {
    return addr; // Example calculation
}
