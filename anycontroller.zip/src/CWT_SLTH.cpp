#include "CWT_SLTH.h"


 CWT_SLTH::CWT_SLTH(){
	Registors = {
		Registor_data{"Device",  0x07d0, 0x0001},
		Registor_data{"Lumem",   0x0006, 0x0001},
		Registor_data{"Humidd",  0x0000, 0x0001},
		Registor_data{"Temp",    0x0001, 0x0001}
	};
	d_type = 4;
}

bool CWT_SLTH::registered = [] {
    std::cout <<"The number of itens is:"<<registeredTypes().size()<<"\n";
    Medidor::RegisterType([]() -> std::shared_ptr<Medidor> { return std::make_shared<CWT_SLTH>(); }, 2);
    std::cout <<"The number of itens is:"<<registeredTypes().size()<<"\n";
    return true;
}();

int CWT_SLTH::GetType(int addr) const {
    return addr; // Example calculation
}//ATBBHXZRgFu7AKcN7R6qWZjHHaDv3CDE8961

 #include "Chint_BiFase.h"


