#include "Medidor.h"


bool Medidor::Conection_test(short index)
{
	return false;
}

Registor_data Medidor::Get_addr(std::string index)
{
	for (int i = 0; i < Registors.size(); i++)
		if (Registors[i].identifier == index)return Registors[i];
	return Registor_data();
}

// AnySensor
std::vector<std::pair<std::function<std::shared_ptr<Medidor>()>, int>>& Medidor::registeredTypes() {
    static std::vector<std::pair<std::function<std::shared_ptr<Medidor>()>, int>> instance;
    return instance;
}

Modbus* Medidor::modbusDevice;

std::shared_ptr<Medidor> Medidor::GetNew(int Addr) {

    for (const auto& pair : registeredTypes()) {

        auto instance = pair.first();
        const Registor_data RD = instance->Get_addr("Device");
        const std::vector<char> hold_data =  modbusDevice->Read_from_Device(Addr, (unsigned char*)&RD.addr, (unsigned char*)&RD.length);

        if (hold_data.size() <= 1) { // If the response is invalid, there is no device on this address
            std::cout << "Resposta invalida\n";
            break;
        }

        short C = (unsigned char)hold_data[1];
        std::cout << "Resposta no endereço:  "<< C <<"\n";

        if (C == 0) {
            std::cout << C << " Leitura inválida!\n";
            continue;
        }
        //getchar();
        if (Addr == C) {
            return instance;
        }
    }
    std::cout << "\n";
    return nullptr;
}

void Medidor::RegisterType(std::function<std::shared_ptr<Medidor>()> creatorFunc, int type) {
    registeredTypes().emplace_back(creatorFunc, type);
}
