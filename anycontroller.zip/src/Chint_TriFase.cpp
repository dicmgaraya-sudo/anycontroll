#include "Chint_TriFase.h"

Chint_TriFase::Chint_TriFase() {
	Registors = {
		Registor_data{"volt",		0x2000,0x0002},
		Registor_data{"amps",		0x200C,0x0002},
		Registor_data{"power",		0x2012,0x0002},

		Registor_data{"FP",			0x202A,0x0002},
		Registor_data{"used",		0x101E,0x0002},
		Registor_data{"generated",	0x1028,0x0002},
		Registor_data{"hertz",		0x2044,0x0002},
		Registor_data{"Bound",		0x002D,0x0001},
		Registor_data{"Device",		0x002E,0x0001},

		Registor_data{"amps_A",		0x200C,0x0002},
		Registor_data{"amps_B",		0x200E,0x0002},
		Registor_data{"amps_C",		0x2010,0x0002},

		Registor_data{"IrAT",	    0x0006,0x0001},

		Registor_data{"volt_AB",	0x2000,0x0002},
		Registor_data{"volt_BC",	0x2002,0x0002},
		Registor_data{"volt_CA",	0x2004,0x0002}
	};

	d_type = 3;
}

bool Chint_TriFase::registered = [] {
    std::cout <<"The number of itens is:"<<registeredTypes().size()<<"\n";
    Medidor::RegisterType([]() -> std::shared_ptr<Medidor> {
                            return std::make_shared<Chint_TriFase>();
                          }, 2);
    std::cout <<"The number of itens is:"<<registeredTypes().size()<<"\n";
    return true;
}();



int Chint_TriFase::GetType(int addr) const {
    // Implementation for this specific derived class
    return addr * 3; // Example calculation
}

