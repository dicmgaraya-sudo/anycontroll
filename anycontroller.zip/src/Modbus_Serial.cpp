#include "Modbus_Serial.h"

namespace {
	short payload_len(const unsigned char* length) {
		if (length == nullptr) {
			return 0;
		}
		return static_cast<short>(2 * length[0]);
	}

	bool response_has_payload(const std::vector<char>& response, short header, short data_len) {
		return data_len > 0
			&& header >= 0
			&& response.size() >= static_cast<size_t>(header) + static_cast<size_t>(data_len);
	}
}

std::vector<char> Modbus_Serial::Read_from_Device(const unsigned char device_ID, const  unsigned char* reg_addr, const unsigned char* length)
{
	if (serial_conn::serial_devices.empty() || reg_addr == nullptr || length == nullptr) {
		return {};
	}

	unsigned char Code_RTU[6] = {
			device_ID,
			0x03,
			reg_addr[1],reg_addr[0],
			length[1],length[0]
	};
	std::vector<unsigned char> crc = Modbus::CRC_16(Code_RTU, sizeof(Code_RTU));

	unsigned char msg[8] = {
					Code_RTU[0],Code_RTU[1],
					Code_RTU[2],Code_RTU[3],
					Code_RTU[4],Code_RTU[5],
					crc[0],crc[1]
					};

	const short data_len = payload_len(length);
	const short header = 3;
	const std::vector<char> res = serial_conn::SendBytes(serial_conn::serial_devices, msg, sizeof(msg));
	if (!response_has_payload(res, header, data_len)) {
		return {};
	}

	return separete_data(res, data_len, header);
}


std::vector<char> Modbus_Serial::Write_to_Device(unsigned char device_ID, unsigned char* reg_addr, unsigned char* length, const unsigned char* data)
{
	if (serial_conn::serial_devices.empty() || reg_addr == nullptr || length == nullptr || data == nullptr) {
		return {};
	}

	unsigned char Code_RTU[9] = {
			device_ID,
			0x10,
			reg_addr[1],reg_addr[0],
			length[1],length[0],
			static_cast<unsigned char>(2 * length[0]),
			data[0],data[1]
	};

	std::vector<unsigned char> crc = Modbus::CRC_16(Code_RTU, sizeof(Code_RTU));

	unsigned char msg[11] = {
					Code_RTU[0],
					Code_RTU[1],
					Code_RTU[2],Code_RTU[3],
					Code_RTU[4],Code_RTU[5],
					Code_RTU[6],
					Code_RTU[7],Code_RTU[8],
					crc[0],crc[1]
					};

	return serial_conn::SendBytes(serial_conn::serial_devices, msg, sizeof(msg));
}

std::vector<char> Modbus_Serial::Send_Request(unsigned char* message)
{
	(void)message;
	return std::vector<char>();
}


void Modbus_Serial::Change_address(unsigned char corrent, unsigned char NEW) {}
