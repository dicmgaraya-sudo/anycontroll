#include "Modbus_TCP.h"

bool Modbus_TCP::MODBUS_TCP_Format = true;
bool Modbus_TCP::MODBUS_RTU_Format = true;

Modbus_TCP::Modbus_TCP(const int f_time, const std::string IP, const int prt)
{
    tcp_conn = TCP_Conn(IP,prt);
}

bool Modbus_TCP::Start_conn()
{
	return tcp_conn.Tcp_Start();
}

std::vector<char> Modbus_TCP::Read_from_Device(const byte device_ID, const  byte* reg_addr, const byte* length)
{
	std::vector<char>  res;

	if (MODBUS_TCP_Format) {
		unsigned char Code_TCP[12] = {
					0x00,0x00,//Transaction
					0x00,0x00,//Protocol
					0x00,0x06,//Byte lenght
					device_ID,
					0x03,//read command
					reg_addr[1],reg_addr[0], //registor
					length[1],length[0]
		};

		//try send it in Modbus TCP format
		res = tcp_conn.SendBytes((unsigned char*)Code_TCP, sizeof(Code_TCP));

		if (res.size() > 1)
		{
			//std::cout << "MODBUS-TCP" << std::endl;
			MODBUS_RTU_Format = false;
			return separete_data(res, 2 * length[0], 9);
		}
	}

	if (MODBUS_RTU_Format) {
		unsigned char Code_RTU[6] = {
				device_ID,					//device
				0x03,						//read command
				reg_addr[1],reg_addr[0],	//registor
				length[1],length[0]
		};
		std::vector<byte> crc = Modbus::CRC_16(Code_RTU, sizeof(Code_RTU));

		unsigned char msg[8] = {
						Code_RTU[0],Code_RTU[1],	//read command
						Code_RTU[2],Code_RTU[3],	//registor
						Code_RTU[4],Code_RTU[5],	//length
						crc[0],crc[1]				//CRC
						};

		res = tcp_conn.SendBytes(msg, sizeof(msg));
		if (res.size() > 1)
		{
			//std::cout << "MODBUS-RTU" << std::endl;
			MODBUS_TCP_Format = false;
			return separete_data(res, 2 * length[0], 3);;
		}
	}

	return res;
}

std::vector<char> Modbus_TCP::Write_to_Device(byte device_ID, byte* reg_addr, byte* length, const byte* data)
{
	std::vector<char>  res;

	if (MODBUS_TCP_Format) {
		const byte Code_TCP[15] = {
				0x00,0x00,//Transaction
				0x00,0x00,//Protocol
				0x00,0x06,//Byte lenght

				device_ID,

				0x10,//write command

				reg_addr[1],reg_addr[0], //registor
				length[1],length[0],
				2 * length[0],
				data[0],data[1]
		};
		res = tcp_conn.SendBytes((unsigned char*)Code_TCP, sizeof(Code_TCP));
	}

	if (MODBUS_RTU_Format) {
		unsigned char Code_RTU[9] = {
				device_ID,
				0x10,//write command
				reg_addr[1],reg_addr[0], //registor
				length[1],length[0],
				2 * length[0],
				data[0],data[1]
		};

		std::vector<byte> crc = Modbus::CRC_16(Code_RTU, sizeof(Code_RTU));

		char msg[11] = {
						Code_RTU[0],                //addr
						Code_RTU[1],	            //write command
						Code_RTU[2],Code_RTU[3],	//registor
						Code_RTU[4],Code_RTU[5],	//length
						Code_RTU[6],                //length 2
						Code_RTU[7],Code_RTU[8],    //Data
						crc[0],crc[1]				//CRC
                        };

		res = tcp_conn.SendBytes((unsigned char*)msg, sizeof(msg));
	}
	return res;
}

std::vector<char> Modbus_TCP::Send_Request(byte* message)
{
	return std::vector<char>();
}


void Modbus_TCP::Change_address(byte corrent, byte NEW) {}

