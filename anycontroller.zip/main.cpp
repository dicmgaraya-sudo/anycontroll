#include <iostream>
#include <string>
#include <thread>
#include <vector>
#include <chrono>
#include <memory>

#include "Chint_BiFase.h"
#include "Chint_TriFase.h"
#include "Modbus_TCP.h"
#include "Modbus_Serial.h"

#include "TCP_Conn.h"
#include "Config_maneger.h"
#include "serial_conn.h"
#include "Utilities.h"
#include "Status_reporter.h"

#include "nlohmann/json.hpp"

void Clear()
{
    system("clear");
}

void thread_kill(bool* kill)
{
    getchar();
    *kill = true;
}

    Modbus *Active_Modbus_device;
    std::vector<Modbus_TCP> TCP_devices;
    std::vector<std::shared_ptr<Medidor>> Devices;
    std::shared_ptr<Medidor> CBF = std::make_shared<Chint_BiFase>();

float message_to_float( const unsigned char equip,
                        const short reg_addr,
                        const short length)
{
    std::vector<char> response = Active_Modbus_device->Read_from_Device((int)equip, (unsigned char*)&reg_addr, (unsigned char*)&length);

    if (response.size() != 0)
    {
        if (length == 1){
            return (short)(unsigned char)response[0] * 16 * 16 + (short)(unsigned char)response[1];
        }else{
            return Utilities::byte_to_float((unsigned char*)&response[0]);
        }
    }
    return 0;
}

std::string get_frame_secure(const Medidor* equip)
{
    nlohmann::json j;
    j["equip"] = equip->addr;

    for (int i = 0; i < equip->Registors.size(); i++)
    {
        Registor_data RD = equip->Registors[i];
        j[RD.identifier] = message_to_float(equip->addr, RD.addr, RD.length);
    }

    j["type"] = equip->d_type;
    j["unique_ID"] = Config_maneger::Setup_ID;

    return "crypt="+Utilities::base32_encode(j.dump());
}

bool Change_address(const unsigned char corrent, const unsigned char NEW)
{
    Registor_data RD = CBF->Get_addr("Device");

    const unsigned char NEW_ADDRESS[] = { 0x00, NEW };

    Active_Modbus_device->Write_to_Device(corrent, (unsigned char*)&RD.addr, (unsigned char*)&RD.length, NEW_ADDRESS);
    std::cout << "trocando endereco \n";
    return true;
}


std::vector<short> findDevices()
{
    std::vector<short> equips;
    bool new_device = false;
    unsigned short available_addr = 1;
    bool is_serial = serial_conn::check_all_Ports();


    auto processAddress = [&](unsigned short i){
        const Registor_data RD = CBF->Get_addr("Device");
        std::cout << "Endereço: " << i << ":  \n";

        if (is_serial) {
            Active_Modbus_device = new Modbus_Serial();
        }

        Medidor::modbusDevice = Active_Modbus_device;

        auto newDevice =  Medidor::GetNew(i);
        if( newDevice ==  nullptr) {
            available_addr = i;
            return;
        }

        Devices.push_back(newDevice);
        equips.push_back(i);

        std::cout << std::dec;

        Devices.back()->addr = i;

        std::cout << "Device type " << Devices.back()->d_type << " Address:" << i << "\n";
        std::cout << "\n";

        if (i < 2)
        {
            std::cout << "Novo dispositivo!\n";
            new_device = true;
            CBF = Devices.back();
        }
    };

    for (short i = 01; i < 240; i++)
    {
        if (serial_conn::serial_devices.size() > 0)
        {
            std::cout <<std::dec<< "Portas: " << serial_conn::serial_devices.size() << "\n";
        }
        processAddress(i);
    }

    if (new_device)
    {
        std::cout << "Encontrado novo dispositivo: " << available_addr << "\n";
        Change_address(0x01, (char)available_addr);
        equips[0] = available_addr;
    }
    else
    {
        std::cout << "Nenhum novo dispositivo encontrado!\n";
    }

    return equips;
}

const int sleepDurationMilliseconds = 1000;

void updateScreen(const std::string& lastResponse, int pastTime, int resolution, int statusPastTime, int statusResolution) {
#ifdef NDEBUG
    (void)lastResponse;
    (void)pastTime;
    (void)resolution;
    (void)statusPastTime;
    (void)statusResolution;
    return;
#else
    Clear();
    const std::string& statusLine = Status_reporter::last_line();
    std::cout << (statusLine.empty() ? "status: ainda nao houve tentativa de POST" : statusLine) << "\n";
    const int remaining = statusResolution - statusPastTime;
    if (remaining > 0) {
        std::cout << "proximo status em " << remaining / 1000 << "s  log=status_report.log\n";
    }
    std::cout << lastResponse << "\n";
    std::cout << std::dec << " Novo Frame: " << pastTime << " / " << resolution << "\n";
#endif
}

void report_controller_status(bool modbus_ok, bool mea_ok, const std::string& mea_detail, long mea_latency_ms) {
    const bool serial_present = serial_conn::serial_devices.size() > 0;
    Status_reporter::send_status(
        modbus_ok,
        serial_present,
        static_cast<int>(Devices.size()),
        mea_ok,
        mea_detail,
        mea_latency_ms
    );
}

void program_tick() {
    bool terminateProgram = false;
    TCP_devices.push_back(Modbus_TCP(0, Config_maneger::adaptor_Addr, 502));
    const bool modbus_ok = TCP_devices.front().Start_conn();
    Active_Modbus_device = &TCP_devices.front();

    if (!modbus_ok) {
        Status_reporter::send_event(
            "modbus_tcp",
            "fail",
            "MODBUS_TCP_DOWN",
            "Falha ao conectar no adaptador " + Config_maneger::adaptor_Addr + ":502"
        );
    }

    auto startTime = std::chrono::steady_clock::now();
    auto endTime = std::chrono::steady_clock::now();
    auto statusStartTime = std::chrono::steady_clock::now();
    const int resolution = 60 * 2 * 1000;
    const int statusResolution = 60 * 5 * 1000;
    Status_reporter::log(
        "status armado url=" + Status_reporter::endpoint_url("save_device_status.php")
        + " base=\"" + Config_maneger::PHP_Server_Addr + "\""
        + " unique_ID=\"" + Config_maneger::Setup_ID + "\""
        + " intervalo_s=" + std::to_string(statusResolution / 1000)
        + " primeiro POST so depois da varredura Modbus"
    );
    if (Config_maneger::PHP_Server_Addr.empty() || Config_maneger::Setup_ID.empty()) {
        Status_reporter::log("status nao sera entregue: config.json incompleta ou nao carregou no cwd atual");
    }
    int pastTime = resolution;
    int statusPastTime = statusResolution;

    const std::vector<short> equips = findDevices();
    TCP_Conn::wait_response = true;
    std::string lastResponse;

    bool last_mea_ok = false;
    std::string last_mea_detail = "ainda nao enviado";
    long last_mea_latency_ms = 0;

    if (Devices.empty()) {
        Status_reporter::send_event(
            "meter",
            modbus_ok ? "warn" : "fail",
            "METER_NONE",
            "Nenhum medidor encontrado na varredura Modbus"
        );
    }

    Status_reporter::log(
        "status varredura terminou devices=" + std::to_string(Devices.size())
        + " modbus_ok=" + std::string(modbus_ok ? "1" : "0")
        + " enviando save_device_status.php"
    );
    report_controller_status(modbus_ok, last_mea_ok, last_mea_detail, last_mea_latency_ms);
    statusStartTime = std::chrono::steady_clock::now();
    statusPastTime = 0;

    while (!terminateProgram) {
        if (pastTime >= resolution) {
            startTime = std::chrono::steady_clock::now();
            lastResponse = "";
            last_mea_ok = false;
            last_mea_detail = Devices.empty() ? "sem frames para enviar" : "aguardando envio";
            last_mea_latency_ms = 0;

            for (short i = 0; i < Devices.size(); i++) {
                std::cout << std::dec << i + 1 << "/" << Devices.size() << "\n";
                const std::string frame = get_frame_secure(Devices[i].get());
                std::cout << frame << "\n";
                const HttpResult serverResponse = Status_reporter::http_post(frame, Config_maneger::PHP_Server_Addr);
                const std::string serverDetail = Status_reporter::brief_detail(serverResponse);
                std::cout << serverDetail << "\n";
                lastResponse += " \n" + frame + " \n" + serverDetail;
                last_mea_latency_ms = serverResponse.latency_ms;

                if (!serverResponse.ok) {
                    last_mea_ok = false;
                    last_mea_detail = "HTTP " + std::to_string(serverResponse.http_code) + " " + serverDetail;
                    Status_reporter::log(
                        "frame FAIL url=" + Config_maneger::PHP_Server_Addr
                        + " equip=" + std::to_string(Devices[i]->addr)
                        + " " + serverDetail
                    );
                    Status_reporter::send_event(
                        "mea",
                        "fail",
                        "MEA_POST_FAIL",
                        "Falha ao enviar frame equip=" + std::to_string(Devices[i]->addr)
                            + " http=" + std::to_string(serverResponse.http_code)
                    );
                } else {
                    last_mea_ok = true;
                    last_mea_detail = "HTTP " + std::to_string(serverResponse.http_code);
                }
            }
        }

        if (statusPastTime >= statusResolution) {
            statusStartTime = std::chrono::steady_clock::now();
            Status_reporter::log("status timer disparou elapsed_ms=" + std::to_string(statusPastTime));
            report_controller_status(modbus_ok, last_mea_ok, last_mea_detail, last_mea_latency_ms);
            statusPastTime = 0;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(sleepDurationMilliseconds));
        updateScreen(lastResponse, pastTime, resolution, statusPastTime, statusResolution);
        endTime = std::chrono::steady_clock::now();
        pastTime = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime).count();
        statusPastTime = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - statusStartTime).count();
    }
}

int main(int argc, char** argv)
{
#ifdef NDEBUG
    std::cout.rdbuf(nullptr);
    std::cerr.rdbuf(nullptr);
#endif
    Config_maneger CM;

    program_tick();

    std::cout << "O programa foi finalizado pelo usuário!\n";

    return EXIT_SUCCESS;
}
