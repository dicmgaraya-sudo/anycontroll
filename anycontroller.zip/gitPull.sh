#!/bin/bash

# Repository URL and directory using SSH
REPO_URL="git@bitbucket.org:pier-system/anycontroller.git"
SCRIPT_DIR=$(dirname "$0")
REPO_DIR="$SCRIPT_DIR"
LOG_FILE="$SCRIPT_DIR/log.txt"  # Log file in the same directory as the script

# Clear the previous log
echo "Clearing previous log..." > "$LOG_FILE"

# Function to check and set CI_ENV from multiple sources
set_ci_env() {
    # Check if CI_ENV is already set
    if [ -z "$CI_ENV" ]; then
        # Try sourcing from global profile (if exists)
        [ -f /etc/profile.d/ci_env.sh ] && source /etc/profile.d/ci_env.sh

        # Try sourcing from user profile (if exists)
        [ -f ~/.ci_env ] && source ~/.ci_env

        # Default to homologacao if CI_ENV is still not set
        CI_ENV=${CI_ENV:-homologacao}
    fi
}

# Apply the function to set CI_ENV
set_ci_env
echo "Checking CI_ENV variable..." >> "$LOG_FILE"
echo "CI_ENV is set to: $CI_ENV" >> "$LOG_FILE"

# Set branch name based on CI_ENV
if [ "$CI_ENV" == "production" ]; then
    BRANCH_NAME="release/Producao"
else    
    BRANCH_NAME="homologacao"
fi
echo "Branch set to: $BRANCH_NAME" >> "$LOG_FILE"

# Function to handle errors and log them
error_exit() {
    echo "Error function called: $1" 1>&2
    echo "$(date): Error - $1" >> "$LOG_FILE"
    exit 1
}

# Log the date and time
echo "Executing gitPull.sh at $(date)" >> "$LOG_FILE"

# Clone or update the repository
if [ -d "$REPO_DIR/.git" ]; then
    echo "Updating the existing repository..." >> "$LOG_FILE"
    cd "$REPO_DIR" || error_exit "Unable to change directory to $REPO_DIR"
    echo "Changed directory to $REPO_DIR" >> "$LOG_FILE"
    
    # Fetching changes and logging
    echo "Fetching changes from repository..." >> "$LOG_FILE"
    git fetch --all 2>&1 >> "$LOG_FILE" || error_exit "Failed to fetch updates"

    git reset --hard HEAD
    # Checkout branch and logging
    echo "Checking out branch $BRANCH_NAME..." >> "$LOG_FILE"
    git checkout "$BRANCH_NAME" 2>&1 >> "$LOG_FILE" || error_exit "Failed to checkout branch $BRANCH_NAME"       

    # Pulling changes and logging
    echo "Pulling changes from branch $BRANCH_NAME..." >> "$LOG_FILE"
    git pull origin "$BRANCH_NAME" 2>&1 >> "$LOG_FILE" || error_exit "Failed to pull from branch $BRANCH_NAME"
    
    # Check if the branch is "producao" and there are changes
    if [ "$BRANCH_NAME" == "release/Producao" ] && [ -n "$(git status --porcelain)" ]; then
        # Check if "rollback" branch exists
        if git show-ref --verify --quiet "refs/heads/rollback"; then
            # Use the existing "rollback" branch
            echo "'rollback' branch already exists. Using it..." >> "$LOG_FILE"
            git checkout -f rollback 2>&1 >> "$LOG_FILE" || error_exit "Failed to checkout 'rollback' branch"
        else
            # Create and checkout "rollback" branch
            echo "Creating 'rollback' branch and merging changes..." >> "$LOG_FILE"
            git checkout -f -b rollback 2>&1 >> "$LOG_FILE" || error_exit "Failed to create and checkout 'rollback' branch"
            git merge "$BRANCH_NAME" 2>&1 >> "$LOG_FILE" || error_exit "Failed to merge changes to 'rollback' branch"
        fi
        
        # Go back to "producao" branch
        git checkout release/Producao 2>&1 >> "$LOG_FILE" || error_exit "Failed to switch back to 'release/Producao' branch"
    fi
    
else
    echo "Cloning the repository..." >> "$LOG_FILE"
    git clone "$REPO_URL" "$REPO_DIR" 2>&1 >> "$LOG_FILE" || error_exit "Failed to clone the repository"
    cd "$REPO_DIR" || error_exit "Unable to change directory to $REPO_DIR"
    echo "Changed directory to $REPO_DIR" >> "$LOG_FILE"
    git checkout "$BRANCH_NAME" 2>&1 >> "$LOG_FILE" || error_exit "Failed to checkout branch $BRANCH_NAME"
fi

chmod 755 gitPull.sh

if [ -f "compile.sh" ]; then
    chmod 755 compile.sh
    ./compile.sh release  > /dev/null 2>&1
else
    echo "compile.sh not found in the current directory."
fi

echo "Git operations completed successfully." >> "$LOG_FILE"